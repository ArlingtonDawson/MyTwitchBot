﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace MyTwitchBot.EventSub
{
        public class ScrollGenerator
        {
            private readonly string _outputPath;

            public ScrollGenerator(string outputPath = "endstream.html")
            {
                _outputPath = outputPath;
            }

            public async Task GenerateAsync(StreamSessionLog log)
            {
                string html = BuildHtml(log);
                await File.WriteAllTextAsync(_outputPath, html);
                Console.WriteLine($"Scroll generated at {_outputPath}");
            }

        private string BuildHtml(StreamSessionLog log)
        {
            string css = GetCss(CalculateScrollDuration(log));
            string body = $@"
        {BuildSubscribersSection(log)}
        {BuildGiftersSection(log)}
        {BuildFollowersSection(log)}
        <div class=""divider""></div>
        <div class=""stream-end"">THANKS FOR WATCHING</div>";

            return $@"<!DOCTYPE html>
<html lang=""en"">
<head>
    <meta charset=""UTF-8"">
    <style>{css}</style>
</head>
<body>
    <div class=""scroll-wrapper"">
        <div class=""scroll-content"">
            {body}
        </div>
    </div>
</body>
</html>";
        }

        private string GetCss(int scrollDuration)
        {
            return @"
        @import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@400;700&display=swap');

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            background-color: transparent;
            color: #ffffff;
            font-family: 'Cinzel', serif;
            overflow: hidden;
            height: 100vh;
        }

        .scroll-wrapper {
            display: flex;
            justify-content: center;
            width: 100%;
        }

        .scroll-content {
            text-align: center;
            animation: scrollUp " + scrollDuration + @"s linear forwards;
            padding: 100vh 0;
            width: 80%;
        }

        @keyframes scrollUp {
            from { transform: translateY(0); }
            to { transform: translateY(-100%); }
        }

        .section-title {
            font-size: 2em;
            font-weight: 700;
            color: #9147ff;
            margin: 60px 0 20px 0;
            text-transform: uppercase;
            letter-spacing: 4px;
        }

        .section-icon { font-size: 1.5em; margin-bottom: 10px; }

        .name {
            font-size: 1.2em;
            color: #ffffff;
            margin: 8px 0;
            letter-spacing: 2px;
        }

        .gifter-count { color: #9147ff; font-size: 0.9em; margin-left: 8px; }

        .divider {
            width: 200px;
            height: 1px;
            background: linear-gradient(to right, transparent, #9147ff, transparent);
            margin: 30px auto;
        }

        .stream-end {
            font-size: 1.5em;
            color: #9147ff;
            letter-spacing: 6px;
            margin-top: 60px;
        }";
        }

        private string BuildSubscribersSection(StreamSessionLog log)
            {
                if (!log.NewSubscribers.Any()) return string.Empty;

                var names = string.Join("\n", log.NewSubscribers
                    .Select(n => $"<div class=\"name\">{n}</div>"));

                return $"""
                <div class="section-icon">⭐</div>
                <div class="section-title">New Subscribers</div>
                <div class="divider"></div>
                {names}
                """;
            }

            private string BuildGiftersSection(StreamSessionLog log)
            {
                if (!log.Gifters.Any()) return string.Empty;

                var names = string.Join("\n", log.Gifters
                    .OrderByDescending(g => g.Value)
                    .Select(g => $"<div class=\"name\">{g.Key}<span class=\"gifter-count\">x{g.Value}</span></div>"));

                return $"""
                <div class="section-icon">🎁</div>
                <div class="section-title">Gift Subscribers</div>
                <div class="divider"></div>
                {names}
                """;
            }

            private string BuildFollowersSection(StreamSessionLog log)
            {
                if (!log.NewFollowers.Any()) return string.Empty;

                var names = string.Join("\n", log.NewFollowers
                    .Select(n => $"<div class=\"name\">{n}</div>"));

                return $"""
                <div class="section-icon">❤️</div>
                <div class="section-title">New Followers</div>
                <div class="divider"></div>
                {names}
                """;
            }

            private int CalculateScrollDuration(StreamSessionLog log)
            {
                int totalEntries = log.NewSubscribers.Count
                    + log.Gifters.Count
                    + log.NewFollowers.Count;

                // Base 30 seconds + 2 seconds per entry, capped at 3 minutes
                return Math.Min(30 + (totalEntries * 2), 180);
            }
        }
    }

