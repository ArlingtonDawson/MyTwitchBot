﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTwitchBot
{
    public class StreakKeeper
    {
        public int Wins { get; private set; } = 0;
        public int Losses { get; private set; } = 0;
        public int StreakCount { get; set; } = 0;
        public string StreakName { get; set; } = string.Empty;



        public void Lose()
        {
            Losses++;
            if(StreakName == "L")
            {  StreakCount++; }
            else { StreakCount=1;
                StreakName = "L";
            }
        }

        public void Win()
        {
            Wins++;
            if (StreakName == "W")
            { StreakCount++; }
            else
            {
                StreakCount = 1;
                StreakName = "W";
            }
        }
        
        public string AddMessage()
        {
            if (StreakCount < 2)
            {
                return "              ";
            }
            string streakType = StreakName == "W" ? "Win" : "Lose";
            return $"Streak: {streakType} {StreakCount}";
        }

        public StreakKeeper Clone()
        {
            return new StreakKeeper
            {
                Wins = this.Wins,
                Losses=this.Losses,
                StreakCount=this.StreakCount,
                StreakName=this.StreakName
            };
        }
    }
}
